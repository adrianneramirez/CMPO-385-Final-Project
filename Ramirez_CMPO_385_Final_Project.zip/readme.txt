HOW TO RUN THE CODE

- Click Play 
- Choose a mood from the drop down menu 
- Press the mouse to produce smoke puff, release to stop the smoke puff 
- Pressing on mouse will also play the audio, and releasing the mouse will also stop the audio 
- You can control smoke position and direction with your mouse cursor